﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Курсовая_работа
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            Plot = new TPlot(g); // Создаем объект типа TPlot.
            double l = g.Width / 5; // Далее рисуем координатную ось.
            double m = g.Height / 5;

            Line vertL = new Line(); // Вертикальная ось.
            vertL.X1 = 0;
            vertL.Y1 = g.Height;
            vertL.X2 = 0;
            vertL.Y2 = 0;
            vertL.Stroke = Brushes.Black;
            vertL.StrokeThickness = 3;
            g.Children.Add(vertL);

            Line horL = new Line(); // Горизонтальная ось.
            horL.X1 = 0;
            horL.X2 = g.Width;
            horL.Y1 = g.Height;
            horL.Y2 = g.Height;
            horL.Stroke = Brushes.Black;
            horL.StrokeThickness = 3;
            g.Children.Add(horL);

            for (int i = 2; i < 49; i++) // Разметка на вертикальной оси.
            {
                Line a = new Line();
                a.X1 = i * 10;
                a.X2 = i * 10;
                a.Y1 = g.Height-10;
                a.Y2 = g.Height;
                a.Stroke = Brushes.Black;
                a.StrokeThickness = 2;
                g.Children.Add(a);
            }

            for (int i = 2; i < 49; i++) // Разметка на горизонтальной оси.
            {
                Line a = new Line();
                a.X1 = 0;
                a.X2 = 10;
                a.Y1 = i * 10;
                a.Y2 = i * 10;
                a.Stroke = Brushes.Black; 
                a.StrokeThickness = 2;
                g.Children.Add(a);
            }

            Polyline vertArr = new Polyline(); // Стрелочка на вертикальной оси.
            vertArr.Points = new PointCollection();
            vertArr.Points.Add(new Point(0, 0));
            vertArr.Points.Add(new Point(10, 10));
            vertArr.Stroke = Brushes.Black;
            vertArr.StrokeThickness = 2;
            g.Children.Add(vertArr);

            Polyline horArr = new Polyline(); // Стрелочка на горизонтальной оси.
            horArr.Points = new PointCollection();
            horArr.Points.Add(new Point(g.Width, g.Height));
            horArr.Points.Add(new Point(g.Width - 10, g.Height - 10));
            horArr.Stroke = Brushes.Black;
            horArr.StrokeThickness = 2;
            g.Children.Add(horArr);

            double R = 8; // Рисуем заданные точки на графике.
            Brush br = Brushes.Black;
            Ellipse O1 = new Ellipse(); // Первая точка.
            O1.Width = R;
            O1.Height = R;
            O1.Fill = br;
            O1.Margin = new Thickness(1 * l, g.Height - 2 * m, 0, 0);
            g.Children.Add(O1);
            
            Ellipse O2 = new Ellipse(); // Вторая точка.
            O2.Width = R;
            O2.Height = R;
            O2.Fill = br;
            O2.Margin = new Thickness(1.2 * l, g.Height - 6 * m, 0, 0);
            g.Children.Add(O2);

            Ellipse O3 = new Ellipse(); // Третья точка.
            O3.Width = R;
            O3.Height = R;
            O3.Fill = br;
            O3.Margin = new Thickness(1.4 * l, g.Height - 4 * m, 0, 0);
            g.Children.Add(O3);

            Ellipse O4 = new Ellipse(); // Четвертая точка.
            O4.Width = R;
            O4.Height = R;
            O4.Fill = br;
            O4.Margin = new Thickness(1.6 * l, g.Height - 4 * m, 0, 0);
            g.Children.Add(O4);

            Ellipse O5 = new Ellipse(); // Пятая точка.
            O5.Width = R;
            O5.Height = R;
            O5.Fill = br;
            O5.Margin = new Thickness(1.8 * l, g.Height - 2 * m, 0, 0);
            g.Children.Add(O5);

            Ellipse O6 = new Ellipse(); // Шестая точка.
            O6.Width = R;
            O6.Height = R;
            O6.Fill = br;
            O6.Margin = new Thickness(1 * l, g.Height - 5 * m, 0, 0);
            g.Children.Add(O6);
        }

        TPlot Plot; // Создадим объект.

        private void bt1_Click(object sender, RoutedEventArgs e) 
        {
            List<Point> P = new List<Point>(); // Создаем список точек.
            double x, y; // Объявляем необходимые переменные.
            x = 0;
            double x1 = 1.0, x2 = 1.2, x3 = 1.4, x4 = 1.6, x5 = 1.8, x6 = 2.0, y1 = 2, y2 = 6, y3 = 4, y4 = 4, y5 = 2, y6 = 5;
            double s0, s1, s2, b0, b1, a0, a1;
            // Используем метод наименьших квадратов.
            s0 = Math.Pow(x1, 0) + Math.Pow(x2, 0) + Math.Pow(x3, 0) + Math.Pow(x4, 0) + Math.Pow(x5, 0) + Math.Pow(x6, 0);
            s1 = Math.Pow(x1, 1) + Math.Pow(x2, 1) + Math.Pow(x3, 1) + Math.Pow(x4, 1) + Math.Pow(x5, 1) + Math.Pow(x6, 1);
            s2 = Math.Pow(x1, 2) + Math.Pow(x2, 2) + Math.Pow(x3, 2) + Math.Pow(x4, 2) + Math.Pow(x5, 2) + Math.Pow(x6, 2);
            b0 = y1 + y2 + y3 + y4 + y5 + y6;
            b1 = y1 * x1 + y2 * x2 + y3 * x3 + y4 * x4 + y5 * x5 + y6 * x6;
            // Решаем систему уравнений методом Крамера.
            double Delta = s0 * s2 - s1 * s1;
            a0 = (b0 * s2 - s1 * b1) / Delta;
            a1 = (s0 * b1 - b0 * s1) / Delta; 

            while (x<= 5.0) // Обозначаем на графике точки, используя полученные из системы уравнений коэффициенты.
            {
                y = a0 + a1*x; // Полином первого порядка.
                P.Add(new Point(x, y));
                x = x+ 0.01;  
            }
            Plot.Draw(P); // Соединяем.
            tb1.Text += "P1(x) = (" + Math.Round(a0,2) + ") + (" + Math.Round(a1,2) + ")x"; // Выводим на экран полученную функцию.
        }

        private void bt2_Click(object sender, RoutedEventArgs e)
        {
            List<Point> P = new List<Point>(); // Обявляем список точек.
            double x, y; // Объявляем необходимые переменные.
            x = 0;
            double x1 = 1.0, x2 = 1.2, x3 = 1.4, x4 = 1.6, x5 = 1.8, x6 = 2.0, y1 = 2, y2 = 6, y3 = 4, y4 = 4, y5 = 2, y6 = 5;
            double s0, s1, s2, s3, s4, b0, b1, b2, a0, a1, a2;
            // Используем метол наименьших квадратов.
            s0 = Math.Pow(x1, 0) + Math.Pow(x2, 0) + Math.Pow(x3, 0) + Math.Pow(x4, 0) + Math.Pow(x5, 0) + Math.Pow(x6, 0);
            s1 = Math.Pow(x1, 1) + Math.Pow(x2, 1) + Math.Pow(x3, 1) + Math.Pow(x4, 1) + Math.Pow(x5, 1) + Math.Pow(x6, 1);
            s2 = Math.Pow(x1, 2) + Math.Pow(x2, 2) + Math.Pow(x3, 2) + Math.Pow(x4, 2) + Math.Pow(x5, 2) + Math.Pow(x6, 2);
            s3 = Math.Pow(x1, 3) + Math.Pow(x2, 3) + Math.Pow(x3, 3) + Math.Pow(x4, 3) + Math.Pow(x5, 3) + Math.Pow(x6, 3);
            s4 = Math.Pow(x1, 4) + Math.Pow(x2, 4) + Math.Pow(x3, 4) + Math.Pow(x4, 4) + Math.Pow(x5, 4) + Math.Pow(x6, 4);
            b0 = y1 + y2 + y3 + y4 + y5 + y6;
            b1 = y1 * x1 + y2 * x2 + y3 * x3 + y4 * x4 + y5 * x5 + y6 * x6;
            b2 = y1 * x1 * x1 + y2 * x2 * x2 + y3 * x3 * x3 + y4 * x4 * x4 + y5 * x5 * x5 + y6 * x6 * x6;
            // Решаем систему уравнений методом Крамера.
            double Delta = s0 * s2 * s4 + s1 * s3 * s2 + s1 * s3 * s2 - s2 * s2 * s2 - s1 * s1 * s4 - s3 * s3 * s0;
            a0 = (b0 * s2 * s4 + s1 * s3 * b2 + b1 * s3 * s2 - s2 * s2 * b2 - s1 * b1 * s4 - s3 * s3 * b0) / Delta;
            a1 = (s0 * b1 * s4 + b0 * s3 * s2 + s1 * b2 * s2 - s2 * s2 * b1 - s1 * b0 * s4 - b2 * s3 * s0) / Delta;
            a2 = (s0 * s2 * b2 + s1 * b1 * s2 + s1 * s3 * b0 - s2 * s2 * b0 - s1 * b2 * s1 - s0 * s3 * b1) / Delta;

            while (x <= 5.0) // Обозначаем на графике точки, используя полученные из системы уравнений коэффициенты.
            {
                y = a0 + a1 * x + a2 * x * x; // Полином второго порядка.
                P.Add(new Point(x, y));
                x = x + 0.01;
            }
            Plot.Draw(P); // Соединяем.
            tb2.Text += "P2(x) = (" + Math.Round(a0, 2) + ") + (" + Math.Round(a1, 2) + ")x + (" + Math.Round(a2,2) + ")x^2"; 
            // Выводим на экран полученную функцию.
        }
    }
    
}
