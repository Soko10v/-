﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Курсовая_работа
{
    class TPlot // Создаем класс.
    {
        Canvas g; // Создаем холст.
        Brush br; // Объявляем кисть.
        public TPlot (Canvas g)
        {
            this.g = g;
            br = Brushes.Black; // Цвет кисти - черный.
        }
        public void Draw(List<Point> P) // Создаем метод, который будет рисовать сам график.
        {
            PointCollection PC = new PointCollection(); // Создаем перменную, состоящую из коллекции точек.

            foreach(Point p in P) // Получаем при обходе списка координаты точек.
            {
                if (p.Y >= 0 && p.X >= 0 && p.Y<=5) // Учитываем, что график не должен выходить за пределы холста.
                {
                    PC.Add(new Point(p.X * g.Width / 5, g.Height - p.Y * g.Height / 5));
                }
                
            }
                Polyline PL = new Polyline(); // Соединяем точки.
                PL.Points = PC;
                PL.Stroke = br;
                PL.StrokeThickness = 2;
                g.Children.Add(PL); // Рисуем сам график.
        }
    }
}
